Tools
====================================
By: [Black Tower Entertainment](http://blacktowerentertainment.com/blog/)

Utilities and tools to simplify development of HTML 5 games.

Copyright 2014 Black Tower Entertainment

 
 Animation Viewer
-------------------------
An HTML5 webpage that allows the user to load THREE.js animated models.
  
 
 MayaThreeExporter
-------------------------
A THREE.js animated model exporter for Maya. 
